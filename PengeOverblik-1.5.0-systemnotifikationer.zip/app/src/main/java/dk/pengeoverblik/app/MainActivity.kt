package dk.pengeoverblik.app

import android.os.Bundle
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID
import java.time.LocalDate

private val Danish = Locale("da", "DK")

private data class Entry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val isIncome: Boolean,
    val category: String,
    val recurring: Boolean = false,
    val owner: String = "Mit budget",
    val payFrequency: String = "Månedligt"
)

private fun money(value: Double): String = NumberFormat.getCurrencyInstance(Danish).format(value)

private data class Bill(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val dueDay: Int,
    val owner: String = "Fælles"
)

private fun daysUntilDue(dueDay: Int): Int {
    val today = LocalDate.now()
    val thisMonthDay = dueDay.coerceAtMost(today.lengthOfMonth())
    var due = today.withDayOfMonth(thisMonthDay)
    if (due.isBefore(today)) {
        val next = today.plusMonths(1)
        due = next.withDayOfMonth(dueDay.coerceAtMost(next.lengthOfMonth()))
    }
    return java.time.temporal.ChronoUnit.DAYS.between(today, due).toInt()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BillReminderNotifications.createChannel(this)
        BillReminderNotifications.scheduleDailyCheck(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4101)
        }
        setContent { PengeOverblikApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PengeOverblikApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("pengeoverblik", Context.MODE_PRIVATE) }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var incomeMode by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }
    var bills by remember { mutableStateOf(loadBills(prefs)) }
    var showAddBill by remember { mutableStateOf(false) }
    var cashBalanceText by remember { mutableStateOf(prefs.getString("cash_balance", "") ?: "") }
    var daysToPaydayText by remember { mutableStateOf(prefs.getString("days_to_payday", "14") ?: "14") }

    fun persist(next: List<Entry>) {
        entries = next
        prefs.edit().putString("entries", JSONArray().apply {
            next.forEach { e -> put(JSONObject().apply {
                put("id", e.id); put("title", e.title); put("amount", e.amount)
                put("income", e.isIncome); put("category", e.category); put("recurring", e.recurring)
                put("owner", e.owner); put("payFrequency", e.payFrequency)
            }) }
        }.toString()).apply()
    }

    fun persistBills(next: List<Bill>) {
        bills = next
        prefs.edit().putString("bills", JSONArray().apply {
            next.forEach { b -> put(JSONObject().apply {
                put("id", b.id); put("title", b.title); put("amount", b.amount)
                put("dueDay", b.dueDay); put("owner", b.owner)
            }) }
        }.toString()).apply()
    }

    val totalIncome = entries.filter { it.isIncome }.sumOf { it.amount }
    val totalExpenses = entries.filterNot { it.isIncome }.sumOf { it.amount }
    val balance = totalIncome - totalExpenses
    val daysToPayday = (daysToPaydayText.toIntOrNull() ?: 14).coerceIn(1, 60)
    val upcomingBills = bills.filter { daysUntilDue(it.dueDay) <= daysToPayday }
    val upcomingBillTotal = upcomingBills.sumOf { it.amount }
    val cashBalance = cashBalanceText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val availableUntilPayday = cashBalance - upcomingBillTotal

    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(
            primary = Color(0xFF244D3D), onPrimary = Color(0xFFFFFBF2),
            background = Color(0xFF101713), surface = Color(0xFF1A241E),
            onSurface = Color(0xFFF5F0E5), onSurfaceVariant = Color(0xFFB6C2B8),
            secondary = Color(0xFFB9D5B5), secondaryContainer = Color(0xFF2B4033),
            tertiary = Color(0xFFE2B69A), tertiaryContainer = Color(0xFF47362C),
            outline = Color(0xFF526256), outlineVariant = Color(0xFF344238)
        ) else lightColorScheme(
            primary = Color(0xFF204B39), onPrimary = Color(0xFFFFFBF2),
            background = Color(0xFFF5F0E5), surface = Color(0xFFFFFCF5),
            onSurface = Color(0xFF202B24), onSurfaceVariant = Color(0xFF69766B),
            secondary = Color(0xFFC8DCC4), secondaryContainer = Color(0xFFE4EDE0),
            tertiary = Color(0xFFAD6548), tertiaryContainer = Color(0xFFF3E2D5),
            outline = Color(0xFF9BA99A), outlineVariant = Color(0xFFE1E4D8)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("PengeOverblik", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleLarge)
                            Text("DIN ØKONOMI · I RO OG ORDEN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
                        }
                    },
                    actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Indstillinger", tint = MaterialTheme.colorScheme.onSurface) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Overblik") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ListAlt, null) }, label = { Text("Poster") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Regninger") })
                    NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Savings, null) }, label = { Text("Mål") })
                }
            },
            floatingActionButton = {
                if (tab == 2) FloatingActionButton(onClick = { showAddBill = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Tilføj regning")
                } else if (tab != 3) FloatingActionButton(onClick = { incomeMode = false; showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Tilføj post")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Dashboard(Modifier.padding(padding), totalIncome, totalExpenses, balance, entries,
                    cashBalance = cashBalance, daysToPayday = daysToPayday, upcomingBillTotal = upcomingBillTotal,
                    availableUntilPayday = availableUntilPayday,
                    onAddIncome = { incomeMode = true; showAdd = true },
                    onAddExpense = { incomeMode = false; showAdd = true },
                    onDelete = { id -> persist(entries.filterNot { it.id == id }) })
                1 -> EntriesScreen(Modifier.padding(padding), entries,
                    onDelete = { id -> persist(entries.filterNot { it.id == id }) },
                    onAdd = { isIncome -> incomeMode = isIncome; showAdd = true })
                2 -> BillsScreen(Modifier.padding(padding), bills, onDelete = { id -> persistBills(bills.filterNot { it.id == id }) }, onAdd = { showAddBill = true })
                else -> GoalsScreen(Modifier.padding(padding), balance)
            }
        }

        if (showAdd) AddEntryDialog(
            initialIncome = incomeMode,
            onDismiss = { showAdd = false },
            onSave = { entry -> persist(entries + entry); showAdd = false }
        )
        if (showAddBill) AddBillDialog(onDismiss = { showAddBill = false }, onSave = { bill -> persistBills(bills + bill); showAddBill = false })
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Indstillinger", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Mørkt tema", fontWeight = FontWeight.SemiBold)
                            Text("Skift mellem lyst og mørkt udtryk", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = darkMode, onCheckedChange = { darkMode = it; prefs.edit().putBoolean("dark_mode", it).apply() })
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    OutlinedTextField(value = cashBalanceText, onValueChange = { cashBalanceText = it; prefs.edit().putString("cash_balance", it).apply() }, label = { Text("Saldo på kontoen lige nu (kr.)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = daysToPaydayText, onValueChange = { daysToPaydayText = it.filter(Char::isDigit).take(2); prefs.edit().putString("days_to_payday", it.filter(Char::isDigit).take(2)).apply() }, label = { Text("Dage til næste løn") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                    Text("Saldo og dage til løn bruges til et estimat frem til næste løn. Regninger trækkes fra, hvis de forfalder inden da.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Text("PengeOverblik · Version 1.4.0\n\nDine budgetposter og regninger gemmes lokalt på telefonen. Appen forbinder ikke til din bank og sender ikke budgetdata til en server.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Færdig") } }
        )
    }
}

private fun loadBills(prefs: android.content.SharedPreferences): List<Bill> {
    val raw = prefs.getString("bills", null) ?: return emptyList()
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Bill(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optDouble("amount"), o.optInt("dueDay", 1).coerceIn(1, 31), o.optString("owner", "Fælles"))
        }
    } catch (_: Exception) { emptyList() }
}

private fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> {
    val raw = prefs.getString("entries", null) ?: return emptyList()
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Entry(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optDouble("amount"), o.optBoolean("income"), o.optString("category"), o.optBoolean("recurring"), o.optString("owner", "Mit budget"), o.optString("payFrequency", "Månedligt"))
        }
    } catch (_: Exception) { emptyList() }
}

@Composable
private fun Dashboard(
    modifier: Modifier,
    income: Double,
    expenses: Double,
    balance: Double,
    entries: List<Entry>,
    onAddIncome: () -> Unit,
    onAddExpense: () -> Unit,
    onDelete: (String) -> Unit,
    cashBalance: Double,
    daysToPayday: Int,
    upcomingBillTotal: Double,
    availableUntilPayday: Double
) {
    val expenseShare = if (income > 0.0) (expenses / income).coerceIn(0.0, 1.0).toFloat() else 0f
    val mineIncome = entries.filter { it.isIncome && it.owner == "Mit budget" }.sumOf { it.amount }
    val mineExpenses = entries.filter { !it.isIncome && it.owner == "Mit budget" }.sumOf { it.amount }
    val partnerIncome = entries.filter { it.isIncome && it.owner == "Partners budget" }.sumOf { it.amount }
    val partnerExpenses = entries.filter { !it.isIncome && it.owner == "Partners budget" }.sumOf { it.amount }
    val sharedIncome = entries.filter { it.isIncome && it.owner == "Fælles" }.sumOf { it.amount }
    val sharedExpenses = entries.filter { !it.isIncome && it.owner == "Fælles" }.sumOf { it.amount }

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)) {
                Text(
                    "DIT ØKONOMISKE OVERBLIK",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = androidx.compose.ui.unit.TextUnit(1.4f, androidx.compose.ui.unit.TextUnitType.Sp)
                )
                Text(
                    "Din økonomi.\nPå dine præmisser.",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold,
                    lineHeight = androidx.compose.ui.unit.TextUnit(37f, androidx.compose.ui.unit.TextUnitType.Sp),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    "Et roligt overblik over det, der kommer ind og går ud.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(30.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(
                            brush = androidx.compose.ui.graphics.Brush.linearGradient(
                                colors = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primary.copy(alpha = 0.88f))
                            )
                        )
                        .padding(22.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(Color(0x28FFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Savings, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("MÅNEDLIGT RÅDERUM", color = Color(0xFFE4EDE4), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, letterSpacing = androidx.compose.ui.unit.TextUnit(0.8f, androidx.compose.ui.unit.TextUnitType.Sp))
                            Text("Indtægter minus registrerede udgifter", color = Color(0xFFD0DED2), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(
                        money(balance),
                        color = Color.White,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(Modifier.height(20.dp))
                    HorizontalDivider(color = Color(0x55FFFFFF))
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("INDTÆGTER", color = Color(0xFFD0DED2), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(money(income), color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("UDGIFTER", color = Color(0xFFD0DED2), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(money(expenses), color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("FREM TIL NÆSTE LØN", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(money(availableUntilPayday), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Estimeret tilbage efter regninger de næste $daysToPayday dage", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Kontosaldo", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(money(cashBalance), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Regninger før løn", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(money(upcomingBillTotal), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    Text(if (cashBalance == 0.0) "Tilføj din aktuelle kontosaldo under Indstillinger for at få et brugbart estimat." else if (availableUntilPayday < 0) "Vær opmærksom: registrerede regninger overstiger den angivne saldo." else "Dagligt pejlemærke: ${money(availableUntilPayday / daysToPayday)} pr. dag, hvis beløbet fordeles jævnt.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onAddIncome,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("Tilføj indtægt", fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onAddExpense,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("Registrér udgift", fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Forbrug af indtægter", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Hvor stor en del er allerede brugt?", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${(expenseShare * 100).toInt()}%", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                    }
                    LinearProgressIndicator(
                        progress = { expenseShare },
                        modifier = Modifier.fillMaxWidth().height(9.dp),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                    Text(
                        if (income > 0) "Registrerede udgifter udgør ${(expenseShare * 100).toInt()}% af dine indtægter." else "Tilføj indtægter og udgifter for at få din personlige oversigt.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Budgetterne", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Personligt og fælles – samlet ét sted", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("${entries.size} poster", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    BudgetMiniRow("Mit budget", "Dit personlige overblik", mineIncome, mineExpenses, MaterialTheme.colorScheme.secondaryContainer)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    BudgetMiniRow("Partners budget", "Din partners personlige overblik", partnerIncome, partnerExpenses, MaterialTheme.colorScheme.tertiaryContainer)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    BudgetMiniRow("Fælles budget", "Poster, I deler", sharedIncome, sharedExpenses, MaterialTheme.colorScheme.secondaryContainer)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Seneste poster", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                Text("${entries.size} i alt", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }
        if (entries.isEmpty()) {
            item { EmptyState("Her starter dit overblik", "Tilføj din første indtægt eller udgift. Dine poster bliver gemt lokalt på telefonen.") }
        } else {
            items(entries.takeLast(4).reversed(), key = { it.id }) { entry -> EntryRow(entry, onDelete) }
        }
        item {
            OutlinedButton(
                onClick = onAddIncome,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(17.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(8.dp))
                Text("Tilføj indtægt", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun BudgetMiniRow(title: String, subtitle: String, income: Double, expenses: Double, tint: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(42.dp).background(tint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Tilbage: ${money(income - expenses)}", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
        }
    }
}
@Composable
private fun MetricCard(title: String, amount: Double, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = tint)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(9.dp))
            Text(money(amount), color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EntriesScreen(modifier: Modifier, entries: List<Entry>, onDelete: (String) -> Unit, onAdd: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        Text("Dine budgetposter", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text("Beløb vises som månedlige beløb. Du kan slette poster med papirkurven.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onAdd(true) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("+ Indtægt") }
            OutlinedButton(onClick = { onAdd(false) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("+ Udgift") }
        }
        Spacer(Modifier.height(8.dp))
        if (entries.isEmpty()) EmptyState("Ingen budgetposter", "Tilføj en indtægt eller udgift for at komme i gang.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) { items(entries, key = { it.id }) { EntryRow(it, onDelete) } }
    }
}

@Composable
private fun EntryRow(entry: Entry, onDelete: (String) -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(if (entry.isIncome) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (entry.isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (entry.isIncome) MaterialTheme.colorScheme.primary else Color(0xFFB64C32))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(listOf(entry.category, entry.owner, if (entry.recurring) "Fast post" else "").filter { it.isNotBlank() }.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                if (entry.payFrequency != "Månedligt") Text("Indtastet: ${entry.payFrequency}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (entry.isIncome) "+ " else "− ") + money(entry.amount), fontWeight = FontWeight.Bold, color = if (entry.isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                IconButton(onClick = { onDelete(entry.id) }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Delete, "Slet ${entry.title}", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}

@Composable
private fun BillsScreen(modifier: Modifier, bills: List<Bill>, onDelete: (String) -> Unit, onAdd: () -> Unit) {
    val sorted = bills.sortedBy { daysUntilDue(it.dueDay) }
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Text("Regningskalender", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface)
        Text("Få overblik over faste regninger og deres forfaldsdag.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
            Column(Modifier.padding(18.dp)) {
                Text("KOMMENDE REGNINGER", color = Color(0xFFE4EDE4), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(money(sorted.sumOf { it.amount }), color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text("Samlet beløb for de registrerede månedlige regninger", color = Color(0xFFD0DED2), style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Tilføj regning") }
        Spacer(Modifier.height(8.dp))
        if (sorted.isEmpty()) EmptyState("Ingen regninger endnu", "Tilføj fx husleje, internet, forsikring eller andre faste regninger. De medregnes i estimatet frem til næste løn.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(sorted, key = { it.id }) { bill ->
                Card(shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Text(bill.dueDay.toString(), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(bill.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Forfalder dag ${bill.dueDay} · ${bill.owner}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(when (daysUntilDue(bill.dueDay)) { 0 -> "Forfalder i dag"; 1 -> "Forfalder i morgen"; else -> "Om ${daysUntilDue(bill.dueDay)} dage" }, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(money(bill.amount), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            IconButton(onClick = { onDelete(bill.id) }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Delete, "Slet ${bill.title}", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddBillDialog(onDismiss: () -> Unit, onSave: (Bill) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var dueDay by remember { mutableStateOf("1") }
    var owner by remember { mutableStateOf("Fælles") }
    var ownerExpanded by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tilføj fast regning", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Navn, fx husleje") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.replace(',', '.').filter { c -> c.isDigit() || c == '.' } }, label = { Text("Beløb pr. måned (kr.)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(value = dueDay, onValueChange = { dueDay = it.filter(Char::isDigit).take(2) }, label = { Text("Forfaldsdag (1–31)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                ExposedDropdownMenuBox(expanded = ownerExpanded, onExpandedChange = { ownerExpanded = !ownerExpanded }) {
                    OutlinedTextField(value = owner, onValueChange = {}, readOnly = true, label = { Text("Budget") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(ownerExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = ownerExpanded, onDismissRequest = { ownerExpanded = false }) {
                        listOf("Mit budget", "Partners budget", "Fælles").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { owner = option; ownerExpanded = false }) }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { val parsed = amount.toDoubleOrNull(); val day = dueDay.toIntOrNull(); if (title.isNotBlank() && parsed != null && parsed > 0 && day != null && day in 1..31) onSave(Bill(title = title.trim(), amount = parsed, dueDay = day, owner = owner)) }, enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0 && (dueDay.toIntOrNull() ?: 0) in 1..31) { Text("Gem regning") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller") } }
    )
}

@Composable
private fun GoalsScreen(modifier: Modifier, balance: Double) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Opsparing og mål", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(20.dp)) {
                Box(Modifier.size(48.dp).background(Color(0xFFE2F4E9), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Savings, null, tint = MaterialTheme.colorScheme.primary) }
                Spacer(Modifier.height(14.dp))
                Text("Muligt månedligt råderum", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(money(balance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                Text("Dette er forskellen mellem dine registrerede indtægter og udgifter – ikke en garanti for, at beløbet kan spares op.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
        }
        EmptyState("Opsparingsmål kommer snart", "I en senere version kan du oprette mål, følge fremskridt og registrere gældsafbetaling.")
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(6.dp)); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEntryDialog(initialIncome: Boolean, onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var isIncome by remember { mutableStateOf(initialIncome) }
    var category by remember { mutableStateOf(if (initialIncome) "Indkomst" else "Andet") }
    var recurring by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var frequency by remember { mutableStateOf("Månedligt") }
    var frequencyExpanded by remember { mutableStateOf(false) }
    var owner by remember { mutableStateOf("Mit budget") }
    var ownerExpanded by remember { mutableStateOf(false) }
    val categories = if (isIncome) listOf("Indkomst", "Løn", "Børnepenge", "Andet") else listOf("Bolig", "Mad", "Transport", "Forsikring", "Regninger", "Gæld", "Opsparing", "Andet")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tilføj budgetpost", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isIncome, onClick = { isIncome = true; category = "Indkomst" }, label = { Text("Indtægt") })
                    FilterChip(selected = !isIncome, onClick = { isIncome = false; category = "Andet" }, label = { Text("Udgift") })
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Navn, fx husleje") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.replace(',', '.').filter { c -> c.isDigit() || c == '.' } }, label = { Text(if (isIncome && frequency == "Hver 14. dag") "Løn i kr. hver 14. dag" else if (isIncome && frequency == "Ugentligt") "Indtægt i kr. pr. uge" else "Beløb i kr. pr. måned") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                if (isIncome) {
                    ExposedDropdownMenuBox(expanded = frequencyExpanded, onExpandedChange = { frequencyExpanded = !frequencyExpanded }) {
                        OutlinedTextField(value = frequency, onValueChange = {}, readOnly = true, label = { Text("Udbetaling") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(frequencyExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = frequencyExpanded, onDismissRequest = { frequencyExpanded = false }) {
                            listOf("Månedligt", "Hver 14. dag", "Ugentligt").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { frequency = option; frequencyExpanded = false }) }
                        }
                    }
                }
                ExposedDropdownMenuBox(expanded = ownerExpanded, onExpandedChange = { ownerExpanded = !ownerExpanded }) {
                    OutlinedTextField(value = owner, onValueChange = {}, readOnly = true, label = { Text("Hvem tilhører posten?") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(ownerExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = ownerExpanded, onDismissRequest = { ownerExpanded = false }) {
                        listOf("Mit budget", "Partners budget", "Fælles").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { owner = option; ownerExpanded = false }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { category = item; expanded = false }) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = recurring, onCheckedChange = { recurring = it }); Text("Fast månedlig post") }
            }
        },
        confirmButton = { Button(onClick = { val parsed = amount.toDoubleOrNull(); if (title.isNotBlank() && parsed != null && parsed > 0) onSave(Entry(title = title.trim(), amount = parsed * when (if (isIncome) frequency else "Månedligt") { "Hver 14. dag" -> 26.0 / 12.0; "Ugentligt" -> 52.0 / 12.0; else -> 1.0 }, isIncome = isIncome, category = category, recurring = recurring, owner = owner, payFrequency = if (isIncome) frequency else "Månedligt")) }, enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) { Text("Gem") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller") } }
    )
}
