# Changelog

## 1.3.0 — Modern dashboard redesign
- Rebuilt the dashboard hierarchy with a clearer monthly balance hero and stronger typography.
- Added quick actions for income and expense entry.
- Reworked personal, partner, and shared budget summaries into a cleaner grouped layout.
- Preserved local storage, recurring entries, owner selection, pay frequency conversion, and light/dark themes.

# Ændringslog

## 1.0.0 — første MVP
- Første native Android-projekt med Jetpack Compose.
- Dashboard for indtægter, udgifter og råderum.
- Opret og slet budgetposter.
- Kategorier og markering af faste månedlige poster.
- Lokal lagring uden netværkspermission.
- Kladdetekster til Google Play og privatlivspolitik.

## 1.0.0-design-refresh
- Opdateret dashboard med mere luft, tydeligere typografi og bløde afrundede kort.
- Nyt farvesystem med dyb grøn, knækket hvid, mint og varm fersken.
- Tilføjet visuel forbrugsindikator for registrerede udgifter i forhold til indtægter.
- Forbedret hierarki for månedsoverblik og seneste poster.
- Bevarer lokal lagring og eksisterende tilføj/slet-funktioner.

## 1.1.0 — Nyt visuelt udtryk
- Opdateret farvepalette og mere roligt, moderne skandinavisk udtryk.
- Tilføjet mulighed for at skifte mellem lyst og mørkt tema; valget gemmes på telefonen.
- Overblik, poster og indstillinger bruger nu farver, der følger det valgte tema.
- Bevarer manuel indtastning, indkomst hver 14. dag/ugentligt og separate budgetejere.


## 1.2.0 — Eksklusivt grønt og cremefarvet redesign
- Opdateret lyst tema til varm creme, dyb skovgrøn og afdæmpede naturfarver.
- Opdateret mørkt tema med dybe grøn-sort nuancer og varme kontraster.
- Samlet farvesystem for kort, navigation, knapper, tekst og status-/navigationsbjælker.
- Bevarer eksisterende skærme, lokal lagring, manuelle poster, lønfrekvenser og budgetejere.


## Version 1.4.0 — Råderum og regningskalender

- Tilføjet manuel registrering af kontosaldo og antal dage til næste løn.
- Dashboard viser et estimat for beløb tilbage efter registrerede regninger før næste løn samt et dagligt pejlemærke.
- Tilføjet regningsoversigt med månedligt beløb, forfaldsdag og budget-ejer (Mit budget, Partners budget eller Fælles).
- Regninger gemmes lokalt på telefonen og kan slettes.
- Eksisterende budgetposter, lønfrekvenser, separate budgetter og lyst/mørkt tema er bevaret.
- Forfaldsvisningen er en lokal oversigt; system-pushnotifikationer er ikke inkluderet i denne version.


## 1.5.0
- Added Android system notifications for registered bills due today or tomorrow.
- Notifications are checked daily at approximately 09:00 and the reminder is rescheduled after device reboot.
- Added Android 13+ notification permission request and a dedicated notification channel.
- Reminder notifications require notification permission to be granted and are not exact-time guarantees.
