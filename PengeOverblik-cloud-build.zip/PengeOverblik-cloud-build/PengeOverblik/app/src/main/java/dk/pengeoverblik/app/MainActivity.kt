package dk.pengeoverblik.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val Danish = Locale("da", "DK")

private data class Entry(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val amount: Double,
    val isIncome: Boolean,
    val category: String,
    val recurring: Boolean = false,
    val owner: String = "Mit budget",
    val payFrequency: String = "Månedligt"
)

private fun money(value: Double): String = NumberFormat.getCurrencyInstance(Danish).format(value)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PengeOverblikApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PengeOverblikApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("pengeoverblik", Context.MODE_PRIVATE) }
    var entries by remember { mutableStateOf(loadEntries(prefs)) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var incomeMode by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", false)) }

    fun persist(next: List<Entry>) {
        entries = next
        prefs.edit().putString("entries", JSONArray().apply {
            next.forEach { e -> put(JSONObject().apply {
                put("id", e.id); put("title", e.title); put("amount", e.amount)
                put("income", e.isIncome); put("category", e.category); put("recurring", e.recurring)
                put("owner", e.owner); put("payFrequency", e.payFrequency)
            }) }
        }.toString()).apply()
    }

    val totalIncome = entries.filter { it.isIncome }.sumOf { it.amount }
    val totalExpenses = entries.filterNot { it.isIncome }.sumOf { it.amount }
    val balance = totalIncome - totalExpenses

    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(
            primary = Color(0xFF285B4C), onPrimary = Color.White,
            background = Color(0xFF101714), surface = Color(0xFF19221D),
            onSurface = Color(0xFFEAF2ED), onSurfaceVariant = Color(0xFFADBCB3),
            secondary = Color(0xFF9AD8C0), secondaryContainer = Color(0xFF29483C),
            tertiaryContainer = Color(0xFF4B332C), outlineVariant = Color(0xFF34453B)
        ) else lightColorScheme(
            primary = Color(0xFF286B5B), onPrimary = Color.White,
            background = Color(0xFFF5F6F1), surface = Color(0xFFFFFFFF),
            onSurface = Color(0xFF202B28), onSurfaceVariant = Color(0xFF748078),
            secondary = Color(0xFFB5E5C8), secondaryContainer = Color(0xFFE1F0E7),
            tertiaryContainer = Color(0xFFF8EAE2), outlineVariant = Color(0xFFE1E7E1)
        )
    ) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("PengeOverblik", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleLarge)
                            Text("DIN ØKONOMI · I RO OG ORDEN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
                        }
                    },
                    actions = { IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Indstillinger", tint = MaterialTheme.colorScheme.onSurface) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Overblik") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ListAlt, null) }, label = { Text("Poster") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Savings, null) }, label = { Text("Mål") })
                }
            },
            floatingActionButton = {
                if (tab != 2) FloatingActionButton(onClick = { incomeMode = false; showAdd = true }, containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.White) {
                    Icon(Icons.Default.Add, contentDescription = "Tilføj post")
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Dashboard(Modifier.padding(padding), totalIncome, totalExpenses, balance, entries,
                    onAddIncome = { incomeMode = true; showAdd = true }, onDelete = { id -> persist(entries.filterNot { it.id == id }) })
                1 -> EntriesScreen(Modifier.padding(padding), entries,
                    onDelete = { id -> persist(entries.filterNot { it.id == id }) },
                    onAdd = { isIncome -> incomeMode = isIncome; showAdd = true })
                else -> GoalsScreen(Modifier.padding(padding), balance)
            }
        }

        if (showAdd) AddEntryDialog(
            initialIncome = incomeMode,
            onDismiss = { showAdd = false },
            onSave = { entry -> persist(entries + entry); showAdd = false }
        )
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Indstillinger", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Mørkt tema", fontWeight = FontWeight.SemiBold)
                            Text("Skift mellem lyst og mørkt udtryk", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = darkMode, onCheckedChange = { darkMode = it; prefs.edit().putBoolean("dark_mode", it).apply() })
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Text("PengeOverblik · Version 1.1.0\n\nDine budgetposter gemmes lokalt på telefonen. Appen forbinder ikke til din bank og sender ikke budgetdata til en server.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Færdig") } }
        )
    }
}

private fun loadEntries(prefs: android.content.SharedPreferences): List<Entry> {
    val raw = prefs.getString("entries", null) ?: return emptyList()
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Entry(o.optString("id", UUID.randomUUID().toString()), o.optString("title"), o.optDouble("amount"), o.optBoolean("income"), o.optString("category"), o.optBoolean("recurring"), o.optString("owner", "Mit budget"), o.optString("payFrequency", "Månedligt"))
        }
    } catch (_: Exception) { emptyList() }
}

@Composable
private fun Dashboard(modifier: Modifier, income: Double, expenses: Double, balance: Double, entries: List<Entry>, onAddIncome: () -> Unit, onDelete: (String) -> Unit) {
    val expenseShare = if (income > 0.0) (expenses / income).coerceIn(0.0, 1.0).toFloat() else 0f
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Dine penge. Dit overblik.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Text("Her er status på din økonomi lige nu.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).background(Color(0x33FFFFFF), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Savings, contentDescription = null, tint = Color.White, modifier = Modifier.size(19.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("TILBAGE EFTER REGISTREREDE POSTER", color = Color(0xFFD9E9E1), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(15.dp))
                    Text(money(balance), color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(20.dp))
                    HorizontalDivider(color = Color(0x55FFFFFF))
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Indtægter", color = Color(0xFFD9E9E1), style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(money(income), color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Udgifter", color = Color(0xFFD9E9E1), style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(money(expenses), color = Color.White, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Forbrug af indtægter", color = MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${(expenseShare * 100).toInt()}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(progress = { expenseShare }, modifier = Modifier.fillMaxWidth().height(8.dp), color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.secondaryContainer)
                    Text(if (income > 0) "Du har registreret udgifter svarende til ${(expenseShare * 100).toInt()}% af dine indtægter." else "Tilføj dine indtægter for at se, hvor stor en del af dem dine udgifter udgør.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("Hurtigt overblik", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard("Indtægter", income, MaterialTheme.colorScheme.secondaryContainer, Modifier.weight(1f))
                MetricCard("Udgifter", expenses, MaterialTheme.colorScheme.tertiaryContainer, Modifier.weight(1f))
            }
        }
        item {
            val mineIncome = entries.filter { it.isIncome && it.owner == "Mit budget" }.sumOf { it.amount }
            val mineExpenses = entries.filter { !it.isIncome && it.owner == "Mit budget" }.sumOf { it.amount }
            val partnerIncome = entries.filter { it.isIncome && it.owner == "Partners budget" }.sumOf { it.amount }
            val partnerExpenses = entries.filter { !it.isIncome && it.owner == "Partners budget" }.sumOf { it.amount }
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Parbudget", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    Text("Oversigt fordelt på person. Fælles poster indgår kun i det samlede overblik.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("Mit budget", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Ind: ${money(mineIncome)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                            Text("Ud: ${money(mineExpenses)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Text("Tilbage: ${money(mineIncome - mineExpenses)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodySmall)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Partners budget", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text("Ind: ${money(partnerIncome)}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                            Text("Ud: ${money(partnerExpenses)}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                            Text("Tilbage: ${money(partnerIncome - partnerExpenses)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Seneste poster", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface)
                Text("${entries.size} i alt", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
            }
        }
        if (entries.isEmpty()) item { EmptyState("Start med din første post", "Tilføj en indtægt eller udgift, så bygger dit overblik sig op her.") }
        items(entries.takeLast(4).reversed(), key = { it.id }) { entry -> EntryRow(entry, onDelete) }
        item {
            OutlinedButton(onClick = onAddIncome, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Tilføj indtægt", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, amount: Double, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = tint)) {
        Column(Modifier.padding(18.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(9.dp))
            Text(money(amount), color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EntriesScreen(modifier: Modifier, entries: List<Entry>, onDelete: (String) -> Unit, onAdd: (Boolean) -> Unit) {
    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(8.dp))
        Text("Dine budgetposter", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text("Beløb vises som månedlige beløb. Du kan slette poster med papirkurven.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onAdd(true) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("+ Indtægt") }
            OutlinedButton(onClick = { onAdd(false) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) { Text("+ Udgift") }
        }
        Spacer(Modifier.height(8.dp))
        if (entries.isEmpty()) EmptyState("Ingen budgetposter", "Tilføj en indtægt eller udgift for at komme i gang.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) { items(entries, key = { it.id }) { EntryRow(it, onDelete) } }
    }
}

@Composable
private fun EntryRow(entry: Entry, onDelete: (String) -> Unit) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).background(if (entry.isIncome) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.tertiaryContainer, CircleShape), contentAlignment = Alignment.Center) {
                Icon(if (entry.isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward, null, tint = if (entry.isIncome) MaterialTheme.colorScheme.primary else Color(0xFFB64C32))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(listOf(entry.category, entry.owner, if (entry.recurring) "Fast post" else "").filter { it.isNotBlank() }.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelMedium)
                if (entry.payFrequency != "Månedligt") Text("Indtastet: ${entry.payFrequency}", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (entry.isIncome) "+ " else "− ") + money(entry.amount), fontWeight = FontWeight.Bold, color = if (entry.isIncome) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                IconButton(onClick = { onDelete(entry.id) }, modifier = Modifier.size(30.dp)) { Icon(Icons.Default.Delete, "Slet ${entry.title}", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}

@Composable
private fun GoalsScreen(modifier: Modifier, balance: Double) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Opsparing og mål", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.padding(20.dp)) {
                Box(Modifier.size(48.dp).background(Color(0xFFE2F4E9), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Savings, null, tint = MaterialTheme.colorScheme.primary) }
                Spacer(Modifier.height(14.dp))
                Text("Muligt månedligt råderum", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(money(balance), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(8.dp))
                Text("Dette er forskellen mellem dine registrerede indtægter og udgifter – ikke en garanti for, at beløbet kan spares op.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
            }
        }
        EmptyState("Opsparingsmål kommer snart", "I en senere version kan du oprette mål, følge fremskridt og registrere gældsafbetaling.")
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(6.dp)); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEntryDialog(initialIncome: Boolean, onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var isIncome by remember { mutableStateOf(initialIncome) }
    var category by remember { mutableStateOf(if (initialIncome) "Indkomst" else "Andet") }
    var recurring by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(false) }
    var frequency by remember { mutableStateOf("Månedligt") }
    var frequencyExpanded by remember { mutableStateOf(false) }
    var owner by remember { mutableStateOf("Mit budget") }
    var ownerExpanded by remember { mutableStateOf(false) }
    val categories = if (isIncome) listOf("Indkomst", "Løn", "Børnepenge", "Andet") else listOf("Bolig", "Mad", "Transport", "Forsikring", "Regninger", "Gæld", "Opsparing", "Andet")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tilføj budgetpost", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isIncome, onClick = { isIncome = true; category = "Indkomst" }, label = { Text("Indtægt") })
                    FilterChip(selected = !isIncome, onClick = { isIncome = false; category = "Andet" }, label = { Text("Udgift") })
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Navn, fx husleje") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it.replace(',', '.').filter { c -> c.isDigit() || c == '.' } }, label = { Text(if (isIncome && frequency == "Hver 14. dag") "Løn i kr. hver 14. dag" else if (isIncome && frequency == "Ugentligt") "Indtægt i kr. pr. uge" else "Beløb i kr. pr. måned") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                if (isIncome) {
                    ExposedDropdownMenuBox(expanded = frequencyExpanded, onExpandedChange = { frequencyExpanded = !frequencyExpanded }) {
                        OutlinedTextField(value = frequency, onValueChange = {}, readOnly = true, label = { Text("Udbetaling") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(frequencyExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded = frequencyExpanded, onDismissRequest = { frequencyExpanded = false }) {
                            listOf("Månedligt", "Hver 14. dag", "Ugentligt").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { frequency = option; frequencyExpanded = false }) }
                        }
                    }
                }
                ExposedDropdownMenuBox(expanded = ownerExpanded, onExpandedChange = { ownerExpanded = !ownerExpanded }) {
                    OutlinedTextField(value = owner, onValueChange = {}, readOnly = true, label = { Text("Hvem tilhører posten?") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(ownerExpanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = ownerExpanded, onDismissRequest = { ownerExpanded = false }) {
                        listOf("Mit budget", "Partners budget", "Fælles").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { owner = option; ownerExpanded = false }) }
                    }
                }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Kategori") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { item -> DropdownMenuItem(text = { Text(item) }, onClick = { category = item; expanded = false }) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(checked = recurring, onCheckedChange = { recurring = it }); Text("Fast månedlig post") }
            }
        },
        confirmButton = { Button(onClick = { val parsed = amount.toDoubleOrNull(); if (title.isNotBlank() && parsed != null && parsed > 0) onSave(Entry(title = title.trim(), amount = parsed * when (if (isIncome) frequency else "Månedligt") { "Hver 14. dag" -> 26.0 / 12.0; "Ugentligt" -> 52.0 / 12.0; else -> 1.0 }, isIncome = isIncome, category = category, recurring = recurring, owner = owner, payFrequency = if (isIncome) frequency else "Månedligt")) }, enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) { Text("Gem") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuller") } }
    )
}
