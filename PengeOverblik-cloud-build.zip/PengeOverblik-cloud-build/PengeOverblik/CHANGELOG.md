# Ændringslog

## 1.0.0 — første MVP
- Første native Android-projekt med Jetpack Compose.
- Dashboard for indtægter, udgifter og råderum.
- Opret og slet budgetposter.
- Kategorier og markering af faste månedlige poster.
- Lokal lagring uden netværkspermission.
- Kladdetekster til Google Play og privatlivspolitik.

## 1.0.0-design-refresh
- Opdateret dashboard med mere luft, tydeligere typografi og bløde afrundede kort.
- Nyt farvesystem med dyb grøn, knækket hvid, mint og varm fersken.
- Tilføjet visuel forbrugsindikator for registrerede udgifter i forhold til indtægter.
- Forbedret hierarki for månedsoverblik og seneste poster.
- Bevarer lokal lagring og eksisterende tilføj/slet-funktioner.

## 1.1.0 — Nyt visuelt udtryk
- Opdateret farvepalette og mere roligt, moderne skandinavisk udtryk.
- Tilføjet mulighed for at skifte mellem lyst og mørkt tema; valget gemmes på telefonen.
- Overblik, poster og indstillinger bruger nu farver, der følger det valgte tema.
- Bevarer manuel indtastning, indkomst hver 14. dag/ugentligt og separate budgetejere.
