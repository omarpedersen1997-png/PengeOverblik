# Start her fra Android-telefonen

Denne pakke indeholder Android-projektet og en GitHub Actions-workflow, som forsøger at bygge en test-APK og en release-AAB i skyen.

## Sådan starter du
1. Hent ZIP-filen og pak den ud i en filhåndteringsapp på telefonen.
2. Åbn https://github.com/ i Chrome og log ind/opret konto.
3. Opret et nyt repository med navnet `PengeOverblik` og vælg ikke at tilføje README, licens eller `.gitignore`.
4. Upload indholdet af mappen `PengeOverblik-cloud-build` til repositoryets rod. Vigtigt: Upload også mappen `.github` og filen `.github/workflows/android-build.yml`. Nogle filhåndteringsapps skjuler mapper, der starter med punktum.
5. Åbn fanen **Actions** i repositoryet. Vælg **Build PengeOverblik Android**, og tryk **Run workflow**. Hvis workflowet ikke vises, kontrollér at `.github/workflows/android-build.yml` er uploadet på den korrekte sti.
6. Hvis bygningen lykkes, åbn workflow-kørslen og hent artifact `PengeOverblik-Android-build`. Artifactet indeholder debug-APK og release-AAB.

## Vigtigt
- Bygningen er ikke blevet kørt eller verificeret endnu.
- Release-AAB'en er ikke signeret til Google Play og er derfor ikke klar til upload som udgivelsesfil.
- Debug-APK kan bruges til indledende installationstest, hvis bygningen lykkes.
- Før offentlig udgivelse skal appen testes, release signeres, privatlivspolitik og Data safety-oplysninger kontrolleres, og Google Play Console-krav opfyldes.
- Del aldrig adgangskoder eller signeringsnøgler i repositoryet.
