# Ændringslog

## 2.0.0 — komplet visuelt redesign
- Ny Cirka-inspireret, men selvstændig lilla/blå og hvid visuel stil.
- Ny forside med fremhævet råderum, indtægter, udgifter og frem til næste løn.
- Nye kompakte nøgletalskort, tydeligere hurtige handlinger og opdeling af personlige og fælles budgetter.
- Bevarer lokale budgetdata, regningsoversigt og daglige regningsnotifikationer fra 1.5.0.
- Versionsnummer opdateret, så den nye APK kan skelnes fra den tidligere version.

## 1.5.0
- Android-systemnotifikationer for regninger.
